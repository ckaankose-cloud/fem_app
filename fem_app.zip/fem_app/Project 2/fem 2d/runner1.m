d1 = 1;
d2 = 1;
p = 2;
m = 2;
R = 0.2;
inclusion = 1; % "1" , "0"

[NL, EL] = circle_D2QU9N(d1, d2, p, m, R, inclusion);
%[NL, EL] = circle_D2QU4N(d1, d2, p, m, R, inclusion);

